This tool is used to calculate ILC beta (fgu) for contracts.

PLease use the tool as follows:

Input:
	> Consists of 2 files i.e. "rdminfo.xlsx" and "eventweight.xlsx".
	> In the sheet "rdminfo.xlsx", input the details such as contractid, contractsectionid, contractnumber, sectionletter, cedant, dbname, anlsid, perspcode, scalefactor 
	  in the template available at "L:\4 Share\Rahul Siempu\Post Event Contract Analysis\Input" in the same format.
	> In the sheet "eventweight.xlsx", input the details of eventid, weight in the template available at "L:\4 Share\Rahul Siempu\Post Event Contract Analysis\Input" 
	  in the same format.
	> After saving the files check the details such as rdm_info, eventweights, art_losspctl in "Ilcbeta_main.R" file and run.

Output:
	> This tool generates 3 files i.e. "log.txt", "ilcbeta.xlsx" and "ilcbeta_cals.xlsx".
	> "log.txt" file consists of the contracts which did not produce any loss.
	> "ilcbeta_cals.xlsx" consits of the calculated values such as mdr, cv, beta_inv etc.
	> "ilcbeta.xlsx" consists of fgu values.



Note: Please note that the final values in the "ilcbeta.xlsx" are not multipled with the scale factor.