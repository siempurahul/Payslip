rm(list = ls())
source("./helper_functions/functions.R")
######################################################################################################
## Read Input data
rdm_info     <- read_excel("//allianzms.sharepoint.com@SSL/DavWWWRoot/teams/DE0055-4281484/8 MiscSTAFF/Rahul Siempu/Post Event Contract Analysis/Input/rdminfo.xlsx", 
                           sheet = "rdminfo")
eventweights <- read_excel("//allianzms.sharepoint.com@SSL/DavWWWRoot/teams/DE0055-4281484/8 MiscSTAFF/Rahul Siempu/Post Event Contract Analysis/Input/eventweight.xlsx", 
                           sheet = "eventweight")
art_losspctl <- 0.835
######################################################################################################
## clean any empty spaces in dbname
rdm_info$dbname <- trimws(rdm_info$dbname, which = c("both"))

## Remove any duplicates in rdm_info
rdm_info <- rdm_info %>%
  unique()

do.call(file.remove, list(list.files("./output", full.names = TRUE)))

rdmport = list()
for (i in 1:nrow(rdm_info)){
  tryCatch({
    dbname <- rdm_info$dbname[i]
    channel <- odbcDriverConnect("driver=ODBC Driver 17 for SQL Server;server=sm801872;trusted_connection=Yes;")
    query <- paste0("select '",dbname,"' as dbname, * from [",dbname,"].dbo.rdm_port where 
                    anlsid = ",rdm_info$anlsid[i]," and eventid in ", vec2sql(eventweights$eventid), 
                    " and perspcode = '", rdm_info$perspcode[i],"'")
    rdmport[[i]] <- sqlQueryDT(channel, query) %>% 
      mutate(contractid = rdm_info$contractid[i]) %>%
      mutate(contractsectionid = rdm_info$contractsectionid[i]) %>%
      mutate(contractnumber = rdm_info$contractnumber[i]) %>%
      mutate(sectionletter = rdm_info$sectionletter[i]) %>%
      mutate(cedant = rdm_info$cedant[i])
  }, error=function(e){
    cat("Check : For the Contract",rdm_info$contractnumber[i],rdm_info$sectionletter[i], 
        rdm_info$cedant[i], "no loss for selected events",file="./output/log.txt","\n", append = T)
  })
}
rdmport_comb = do.call(rbind.data.frame,rdmport)

source("./helper_functions/ilcbeta_calculations.R")
getwd()
## Write Output to an excel file
write.xlsx(ilcbeta_fgu, file="./output/ilcbeta.xlsx", sheetName="ilcbeta_fgu", row.names=FALSE)
write.xlsx(ilcbeta, file="./output/ilcbeta_cals.xlsx", sheetName="ilcbeta_cals", row.names=FALSE)