# Retrieve ODBC query result in data.table format
sqlQueryDT <- function(channel, query, ...) {
  out <- sqlQuery(channel, query, na.strings = "", ...) %>%
    as.data.table()
  setnames(out, tolower(names(out)))
}