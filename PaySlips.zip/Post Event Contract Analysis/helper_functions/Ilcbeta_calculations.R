ilcbeta <- rdmport_comb %>%
  left_join(rdm_info, by = c("contractid", "contractsectionid", "contractnumber", 
                             "sectionletter", "dbname" , "anlsid", "perspcode",
                             "cedant")) %>% 
  as.data.frame() %>%
  rowwise() %>%
  mutate(cv = rmsEltCv(stddevi, stddevc, perspvalue)) %>%
  mutate(mdr = rmsEltMdr(perspvalue, expvalue)) %>%
  mutate(parmA = rmsEltParmA(mdr, cv)) %>%
  mutate(parmB = rmsEltParmB(parmA, mdr)) %>%
  mutate(beta_inv = expvalue * qbeta(art_losspctl, parmA, parmB, ncp = 0, lower.tail = TRUE, log.p = FALSE)) %>%
  left_join(eventweights, by = "eventid") %>%
  mutate(beta_inv_weighted = beta_inv * weight) %>%
  mutate(beta_mean_loss = perspvalue * weight) %>%
  select(contractid:cedant, dbname, anlsid, perspcode, scalefactor, eventid, perspvalue:expvalue, cv:beta_mean_loss)

ilcbeta_fgu <- ilcbeta %>% 
  select(contractid, contractsectionid, contractnumber, sectionletter, 
         cedant, dbname, anlsid, scalefactor, beta_inv_weighted, beta_mean_loss) %>%
  dplyr::rename(fgu = beta_inv_weighted) %>%
  group_by(contractid, contractsectionid, contractnumber, 
           sectionletter, cedant, dbname, anlsid, scalefactor) %>%
  summarise_all(sum) %>% 
  as.data.frame()