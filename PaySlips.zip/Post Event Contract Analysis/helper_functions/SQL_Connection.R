# Make SQL connection
makeOdbcConnection <-  function(dbname = "RMS_RDM",
                                server = "art-sql-rms", 
                                driver = "SQL Server") {
  # require(RODBC)
  conn_str <- paste0("Driver= {", driver, "}; ",
                     "Server=", server, "; ",
                     "Database=", dbname, "; ")
  cn <- odbcDriverConnect(conn_str)
  return(cn)
}