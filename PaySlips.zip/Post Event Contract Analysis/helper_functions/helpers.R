# Range of integers expressed in SQL BETWEEN ... AND ... syntax
seq2rng <- function(x) {
  if (length(x) == 1) {
    return(paste0("= ", x))
  } else {
    return(paste0("between ", min(x), " and ", max(x)))
  }
}

# Convert R Vector (numeric or string) to SQL list
vec2sql <- function(vec) {
  if (is.character(vec)) {
    out <- paste0("(", paste0(paste0("'", vec, ","), collapse = ","), ")")
  } else {
    out <- paste0("(", paste0(vec, collapse = ","), ")")
  }
  return(out)
}

# Write a list of tables to Excel
tables_to_excel <- function(list_of_tables, xl_file_path
                            , startRow = 1
                            , firstActiveRow = 2
                            , firstActiveCol = 4
) {
  tbl_names <- names(list_of_tables)
  
  if (!("out_file" %in% tbl_names)) {
    list_of_tables <- c(list_of_tables,
                        list(out_file =
                               tibble(file_path = xl_file_path,
                                      folder_name = dirname(file_path),
                                      file_name = basename(file_path)
                               )
                        )
    )
  }
  
  if (!("r_session_info" %in% tbl_names)) {
    list_of_tables <- c(list_of_tables,
                        list(r_session_info =
                               tibble(info = capture.output(sessionInfo()))
                        )
    )
  }
  
  hdr_sty <- createStyle(halign = "LEFT",
                         wrapText = TRUE,
                         fontColour = "#333399",
                         border = "Bottom"
  )
  
  wb <- write.xlsx(x = list_of_tables, file = xl_file_path
                   , asTable = TRUE
                   , gridLines = FALSE
                   , tableStyle = "None"
                   , headerStyle = hdr_sty
                   , startRow = startRow
                   , firstActiveRow = firstActiveRow
                   , firstActiveCol = firstActiveCol)
  
  return(wb)
}
