# RMS ELT Coefficient of Variation
rmsEltCv <- function(stddevi, stddevc, perspvalue) {
  (stddevi + stddevc) / perspvalue
}

# Mean Damage Ratio
rmsEltMdr <- function(perspvalue, expvalue) {
  perspvalue / expvalue
}

# RMS ELT Beta Distribution Parameter A
rmsEltParmA <- function(val_mdr, val_cv) {
  # Returns Beta Dist parameter A
  (1 - val_mdr) / val_cv^2 - val_mdr
}

# RMS ELT Beta Distribution Parameter B
rmsEltParmB <- function(parmA, val_mdr) {
  # Returns Beta Dist parameter B (need parameter A first)
  parmA * (1 - val_mdr) / val_mdr
}